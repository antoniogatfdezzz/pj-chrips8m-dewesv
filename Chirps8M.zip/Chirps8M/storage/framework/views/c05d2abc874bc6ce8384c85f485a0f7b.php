<?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Paginación" class="mt-6 flex justify-center">
        <ul class="inline-flex items-center gap-1">
            
            <?php if($paginator->onFirstPage()): ?>
                <li>
                    <span class="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-full border border-slate-200 bg-slate-50 text-slate-400 cursor-default select-none">
                        Anterior
                    </span>
                </li>
            <?php else: ?>
                <li>
                    <a
                        href="<?php echo e($paginator->previousPageUrl()); ?>"
                        rel="prev"
                        class="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-full border border-slate-200 bg-white text-slate-700 hover:bg-purple-50 hover:text-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-1 transition"
                    >
                        Anterior
                    </a>
                </li>
            <?php endif; ?>

            
            <?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <?php if(is_string($element)): ?>
                    <li>
                        <span class="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-full text-slate-400 select-none"><?php echo e($element); ?></span>
                    </li>
                <?php endif; ?>

                
                <?php if(is_array($element)): ?>
                    <?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($page == $paginator->currentPage()): ?>
                            <li>
                                <span class="inline-flex items-center px-3 py-1.5 text-xs font-semibold rounded-full border border-purple-600 bg-purple-600 text-white shadow-sm select-none">
                                    <?php echo e($page); ?>

                                </span>
                            </li>
                        <?php else: ?>
                            <li>
                                <a
                                    href="<?php echo e($url); ?>"
                                    class="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-full border border-slate-200 bg-white text-slate-700 hover:bg-purple-50 hover:text-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-1 transition"
                                >
                                    <?php echo e($page); ?>

                                </a>
                            </li>
                        <?php endif; ?>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            
            <?php if($paginator->hasMorePages()): ?>
                <li>
                    <a
                        href="<?php echo e($paginator->nextPageUrl()); ?>"
                        rel="next"
                        class="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-full border border-slate-200 bg-white text-slate-700 hover:bg-purple-50 hover:text-purple-700 focus:outline-none focus:ring-2 focus:ring-purple-500 focus:ring-offset-1 transition"
                    >
                        Siguiente
                    </a>
                </li>
            <?php else: ?>
                <li>
                    <span class="inline-flex items-center px-3 py-1.5 text-xs font-medium rounded-full border border-slate-200 bg-slate-50 text-slate-400 cursor-default select-none">
                        Siguiente
                    </span>
                </li>
            <?php endif; ?>
        </ul>
    </nav>
<?php endif; ?>
<?php /**PATH /Users/antoniogatfernandez/Documents/chirper-8M/resources/views/vendor/pagination/tailwind.blade.php ENDPATH**/ ?>