<?php if (isset($component)) { $__componentOriginal23a33f287873b564aaf305a1526eada4 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal23a33f287873b564aaf305a1526eada4 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.layout','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('title', null, []); ?> 
        Editar Meme
     <?php $__env->endSlot(); ?>

    <div class="max-w-2xl mx-auto">
        <div class="mt-4 mb-4 flex flex-col gap-2">
            <h1 class="text-3xl md:text-4xl font-semibold tracking-tight text-slate-900">Editar meme</h1>
            <p class="text-sm md:text-base text-slate-600">
                Ajusta el contenido o la explicación de tu meme. Los cambios se aplicarán a partir de ahora.
            </p>
        </div>

        <div class="bg-white border border-slate-200 shadow-sm rounded-2xl p-6 md:p-7 mt-4">
            <form method="POST" action="/memes/<?php echo e($meme->id); ?>">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <div class="mb-4">
                    <label for="meme_url" class="block text-xs font-semibold tracking-wide text-slate-700 uppercase mb-2">Meme</label>
                    <textarea
                        name="meme_url"
                        id="meme_url"
                        placeholder="Escribe una URL de imagen o un texto para el meme"
                        class="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 text-sm resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none <?php $__errorArgs = ['meme_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500/70 ring-1 ring-red-500/70 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        rows="3"
                        maxlength="500"
                        required
                    ><?php echo e(old('meme_url', $meme->meme_url)); ?></textarea>
                    <?php $__errorArgs = ['meme_url'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600 font-medium"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="explicacion" class="block text-xs font-semibold tracking-wide text-slate-700 uppercase mb-2">Explicación</label>
                    <textarea
                        name="explicacion"
                        id="explicacion"
                        placeholder="Explica por qué este meme es relevante para el 8M..."
                        class="w-full px-4 py-3 rounded-xl bg-slate-50 border border-slate-200 text-slate-900 placeholder-slate-400 text-sm resize-none focus:ring-2 focus:ring-purple-500 focus:border-transparent outline-none <?php $__errorArgs = ['explicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500/70 ring-1 ring-red-500/70 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                        rows="4"
                        maxlength="1000"
                        required
                    ><?php echo e(old('explicacion', $meme->explicacion)); ?></textarea>
                    <?php $__errorArgs = ['explicacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-1 text-xs text-red-600 font-medium"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="flex justify-between">
                    <a href="/" class="bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium py-2 px-4 rounded-full text-sm shadow-sm">
                        Cancelar
                    </a>
                    <button type="submit" class="bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-6 rounded-full text-sm shadow-sm transition">
                        Actualizar meme
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $attributes = $__attributesOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__attributesOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal23a33f287873b564aaf305a1526eada4)): ?>
<?php $component = $__componentOriginal23a33f287873b564aaf305a1526eada4; ?>
<?php unset($__componentOriginal23a33f287873b564aaf305a1526eada4); ?>
<?php endif; ?>
<?php /**PATH /Users/antoniogatfernandez/Documents/chirper-8M/resources/views/memes/edit.blade.php ENDPATH**/ ?>