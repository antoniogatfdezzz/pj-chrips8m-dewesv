<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['meme']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['meme']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<div class="w-full max-w-xl perspective">
    <div x-data="{ flipped: false }" class="relative w-full min-h-[34rem] h-auto"
         :class="flipped ? 'rotate-y-180' : ''"
         @click.away="flipped = false"
         style="transform-style: preserve-3d; transition: transform 0.6s;">

        
        <div class="absolute w-full h-full backface-hidden flex flex-col bg-white border border-slate-200 shadow-md rounded-2xl p-5">

            
            <div class="flex items-center justify-between mb-4">
                <div class="flex items-center space-x-3">
                    <?php if($meme->user): ?>
                            <img src="https://avatars.laravel.cloud/<?php echo e(urlencode($meme->user->email)); ?>"
                                alt="<?php echo e($meme->user->name); ?>'s avatar" class="w-12 h-12 rounded-full ring-2 ring-purple-400/60" />
                        <div class="flex flex-col">
                            <span class="font-semibold text-slate-900"><?php echo e($meme->user->name); ?></span>
                            <div class="flex items-center gap-1">
                                <span class="text-xs text-slate-500"><?php echo e($meme->fecha_subida->diffForHumans()); ?></span>
                                <?php if($meme->updated_at->gt($meme->created_at->addSeconds(5))): ?>
                                    <span class="text-slate-400">·</span>
                                    <span class="text-xs text-slate-500 italic">editado</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php else: ?>
                        <img src="https://avatars.laravel.cloud/f61123d5-0b27-434c-a4ae-c653c7fc9ed6?vibe=stealth"
                            alt="Usuario anónimo" class="w-12 h-12 rounded-full ring-2 ring-slate-300/80" />
                        <div class="flex flex-col">
                            <span class="font-semibold text-slate-900">Anónimo</span>
                            <div class="flex items-center gap-1">
                                <span class="text-xs text-slate-500"><?php echo e($meme->fecha_subida->diffForHumans()); ?></span>
                                <?php if($meme->updated_at->gt($meme->created_at->addSeconds(5))): ?>
                                    <span class="text-slate-400">·</span>
                                    <span class="text-xs text-slate-500 italic">editado</span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>

                
                
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('update', $meme)): ?>
                        <div class="flex items-center gap-2">
                            <a
                                href="/memes/<?php echo e($meme->id); ?>/edit"
                                class="inline-flex items-center gap-1 rounded-full border border-slate-200 bg-slate-50 px-3 py-1 text-[11px] font-medium text-slate-800 hover:bg-slate-100 hover:border-slate-300 transition">
                                Editar
                            </a>
                            <form method="POST" action="/memes/<?php echo e($meme->id); ?>">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('DELETE'); ?>
                                <button
                                    type="submit"
                                    class="inline-flex items-center gap-1 rounded-full border border-red-200 bg-red-50 px-3 py-1 text-[11px] font-medium text-red-700 hover:bg-red-100 hover:border-red-300 transition">
                                    Eliminar
                                </button>
                            </form>
                        </div>
                    <?php endif; ?>
            </div>

            
            <div class="flex-1 flex flex-col items-center justify-center overflow-hidden">
                <?php
                    $isUrl = \Illuminate\Support\Str::startsWith($meme->meme_url, ['http://', 'https://']);
                ?>

                <?php if($isUrl): ?>
                    <img src="<?php echo e($meme->meme_url); ?>" alt="Meme" class="rounded-xl w-full h-auto max-h-[70vh] object-cover border border-slate-200 shadow-md">
                <?php else: ?>
                    <p class="text-xl md:text-2xl text-center text-slate-900 break-words whitespace-pre-line">
                        <?php echo e($meme->meme_url); ?>

                    </p>
                <?php endif; ?>
            </div>

            
                <button @click.stop="flipped = true"
                    class="mt-4 bg-purple-600 hover:bg-purple-700 text-white font-semibold py-2 px-6 rounded-full shadow-md mx-auto block text-sm">
                Ver explicación
            </button>

        </div>

        
        <div class="absolute w-full h-full backface-hidden rotate-y-180 flex flex-col bg-white border border-slate-200 shadow-md rounded-2xl p-5 justify-between">
            
            <div class="flex-1 flex items-center justify-center text-center">
                <p class="text-slate-900 text-lg leading-relaxed"><?php echo e($meme->explicacion); ?></p>
            </div>

            
            <div class="flex justify-center">
                <button @click.stop="flipped = false"
                    class="bg-slate-100 hover:bg-slate-200 text-slate-800 font-medium py-2 px-5 rounded-full text-sm shadow-sm">
                    Volver al meme
                </button>
            </div>
        </div>
    </div>
</div>


<style>
.perspective {
    perspective: 1000px;
}
.rotate-y-180 {
    transform: rotateY(180deg);
}
.backface-hidden {
    backface-visibility: hidden;
}
</style>
<?php /**PATH /Users/antoniogatfernandez/Documents/chirper-8M/resources/views/components/meme.blade.php ENDPATH**/ ?>